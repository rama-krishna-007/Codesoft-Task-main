# Codsoft-Tasks
First you have to install the ZIP file and then Extract the file 
Then you have to go through the folder and Run the main code then you may get the output
If you want to see the code then you have to select the file and open the code using respective coding platform
